# FotoCRM - Sistema de Gestión de Fotos Bilingüe

Sistema completo para gestionar catálogo de fotos con tags, búsqueda avanzada y configurador interactivo.

## 🚀 Instalación

1. **Descomprimir** este archivo en la raíz de tu hosting (public_html o www)
2. **Acceder** al sitio desde tu navegador
3. **Panel de administración**: Ir a `/admin.html`

## 🔑 Credenciales por defecto

- **Usuario**: `admin`
- **Contraseña**: `admin123`

⚠️ **IMPORTANTE**: Cambia la contraseña inmediatamente después del primer login desde el panel de administración.

## 📁 Estructura de carpetas

```
/
├── index.html          # Frontend público
├── admin.html          # Panel de administración
├── assets/             # CSS y JS compilados
├── api/                # Backend PHP
│   ├── index.php       # API principal
│   └── locales/        # Traducciones backend
├── data/               # Datos de la aplicación (protegido)
│   ├── config.json     # Configuración del sistema
│   ├── categories.json # Tags y categorías
│   ├── photos.json     # Base de datos de fotos
│   └── buckets.json    # Configuraciones guardadas
├── uploads/            # Imágenes subidas
└── backups/            # Backups automáticos (protegido)
```

## ⚙️ Requisitos del servidor

- **PHP**: 7.4 o superior
- **Extensiones PHP**:
  - JSON
  - GD o Imagick (para manipulación de imágenes)
  - ZipArchive (para backups)
- **Apache** con mod_rewrite (o Nginx con configuración similar)
- Permisos de escritura en:
  - `/data`
  - `/uploads`
  - `/backups`

## 🌍 Características

### Multilingüe (Español/Inglés)
- Interfaz completa en ambos idiomas
- Cambio de idioma en tiempo real
- Todos los textos configurables desde el admin

### Panel de Administración
- Gestión de fotos con tags
- Sistema de buckets para organizar subidas
- Configuración de tags personalizados (multilingüe)
- Backup/Restore automático
- Configuración de contacto (WhatsApp/Telegram)
- Personalización de textos del sitio

### Frontend Público
- Buscador avanzado con filtros múltiples
- Vista en árbol de categorías
- Configurador interactivo
- Modo oscuro automático
- Responsive (móvil y desktop)

## 🔧 Configuración inicial

1. **Permisos de carpetas**:
   ```bash
   chmod 755 data uploads backups
   ```

2. **Verificar .htaccess**:
   - Las carpetas `data/` y `backups/` deben estar protegidas
   - El archivo `.htaccess` en cada una debe existir

3. **Configurar contacto** (opcional):
   - Ir a Admin > Configuración > Contacto
   - Activar WhatsApp o Telegram
   - Configurar números/usuarios y mensajes

4. **Subir fotos**:
   - Ir a Admin > Subir fotos
   - Arrastrar imágenes o seleccionar archivos
   - Asignar tags a cada foto
   - Guardar

## 📝 Tags de ejemplo incluidos

El sistema viene con tags de ejemplo para cuchillos artesanales:

**Tipo**: Cocina, Asado, Japonés, Outdoor, Camping, Caza
**Encabado**: Lapacho, Micarta, Resina, Ébano, Olivo, Guayacán, Quebracho
**Acero**: Inoxidable, Carbono, Damasco Inoxidable, Damasco Carbono
**Estilo**: Moderno, Clásico, Rústico

Puedes modificar, agregar o eliminar tags desde el panel de administración.

## 🔒 Seguridad

- Las contraseñas se almacenan con bcrypt
- Archivos de datos protegidos con .htaccess
- Sistema de autenticación para todas las operaciones admin
- Validación de archivos subidos
- Protección contra inyección SQL (sin base de datos)

## 🆘 Soporte

Para reportar problemas o solicitar funcionalidades:
- GitHub: https://github.com/pablopeu/fotocrm/issues

## 📄 Licencia

MIT License - Uso libre con atribución

---

**Versión**: 2.0.0 (Enero 2026)
**Última actualización**: Sistema bilingüe completo con i18n
